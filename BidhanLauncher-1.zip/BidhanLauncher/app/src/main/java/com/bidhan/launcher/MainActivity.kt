package com.bidhan.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bidhan.launcher.data.AppInfo
import com.bidhan.launcher.data.AppRepository
import com.bidhan.launcher.data.PrefsManager
import com.bidhan.launcher.ui.AppDrawerScreen
import com.bidhan.launcher.ui.HomeScreen
import com.bidhan.launcher.ui.SettingsScreen
import com.bidhan.launcher.ui.theme.BidhanLauncherTheme
import kotlinx.coroutines.launch

private enum class Screen { HOME, DRAWER, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BidhanLauncherTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    BidhanLauncherApp()
                }
            }
        }
    }
}

@Composable
fun BidhanLauncherApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var screen by remember { mutableStateOf(Screen.HOME) }

    val allApps = remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    LaunchedEffect(Unit) {
        allApps.value = AppRepository.getLaunchableApps(context)
    }

    val hiddenApps by PrefsManager.hiddenApps(context).collectAsStateWithLifecycle(initialValue = emptySet())
    val homeAppsSet by PrefsManager.homeApps(context).collectAsStateWithLifecycle(initialValue = emptySet())
    val customNames by PrefsManager.customNames(context).collectAsStateWithLifecycle(initialValue = emptyMap())

    val visibleApps = remember(allApps.value, hiddenApps, customNames) {
        allApps.value
            .filter { it.packageName !in hiddenApps }
            .map { app ->
                val newLabel = customNames[app.packageName]
                if (newLabel != null) app.copy(label = newLabel) else app
            }
    }

    val homeApps = remember(visibleApps, homeAppsSet) {
        visibleApps.filter { it.packageName in homeAppsSet }
    }

    when (screen) {
        Screen.HOME -> HomeScreen(
            homeApps = homeApps,
            onLaunch = { pkg -> AppRepository.launch(context, pkg) },
            onLongPressApp = { app ->
                scope.launch { PrefsManager.toggleHome(context, app.packageName) }
            },
            onOpenDrawer = { screen = Screen.DRAWER },
            onOpenSettings = { screen = Screen.SETTINGS }
        )
        Screen.DRAWER -> AppDrawerScreen(
            allApps = visibleApps,
            homeAppPackages = homeAppsSet,
            onBack = { screen = Screen.HOME },
            onLaunch = { pkg -> AppRepository.launch(context, pkg) },
            onToggleHome = { pkg -> scope.launch { PrefsManager.toggleHome(context, pkg) } },
            onToggleHidden = { pkg -> scope.launch { PrefsManager.toggleHidden(context, pkg) } }
        )
        Screen.SETTINGS -> SettingsScreen(
            allApps = allApps.value,
            hiddenApps = hiddenApps,
            onBack = { screen = Screen.HOME },
            onUnhide = { pkg -> scope.launch { PrefsManager.toggleHidden(context, pkg) } },
            onRename = { pkg, name -> scope.launch { PrefsManager.setCustomName(context, pkg, name) } }
        )
    }
}

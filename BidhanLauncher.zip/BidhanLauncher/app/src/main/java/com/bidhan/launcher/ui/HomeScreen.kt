package com.bidhan.launcher.ui

import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bidhan.launcher.data.AppInfo
import com.bidhan.launcher.physics.FloatingIconEngine
import com.bidhan.launcher.ui.theme.TermBg
import com.bidhan.launcher.ui.theme.TermGreen
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun Drawable.toBitmap(size: Int): android.graphics.Bitmap {
    val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bmp
}

private fun loadCustomIconBitmap(context: android.content.Context, uriString: String, size: Int): android.graphics.Bitmap? {
    return try {
        context.contentResolver.openInputStream(Uri.parse(uriString))?.use { stream ->
            val src = android.graphics.BitmapFactory.decodeStream(stream)
            android.graphics.Bitmap.createScaledBitmap(src, size, size, true)
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * A menu of actions for one home-screen icon: rename, pick a custom icon
 * from the gallery, or remove it from the home screen.
 */
sealed class HomeIconAction {
    data class Rename(val pkg: String, val newName: String) : HomeIconAction()
    data class ChangeIcon(val pkg: String, val uri: String) : HomeIconAction()
    data class RemoveFromHome(val pkg: String) : HomeIconAction()
}

@Composable
fun HomeScreen(
    homeApps: List<AppInfo>,
    customIcons: Map<String, String>,
    onLaunch: (String) -> Unit,
    onIconAction: (HomeIconAction) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    var canvasSize by remember { mutableStateOf(Offset.Zero) }
    val iconRadiusPx = with(density) { 28.dp.toPx() }

    val bitmaps = remember(homeApps, customIcons) {
        homeApps.associate { app ->
            val custom = customIcons[app.packageName]?.let { loadCustomIconBitmap(context, it, 160) }
            app.packageName to (custom ?: app.icon.toBitmap(160)).asImageBitmap()
        }
    }

    var engine by remember(homeApps, canvasSize) { mutableStateOf<FloatingIconEngine?>(null) }

    LaunchedEffect(homeApps, canvasSize) {
        if (canvasSize.x > 0 && canvasSize.y > 0 && homeApps.isNotEmpty()) {
            val rect = Rect(0f, 0f, canvasSize.x, canvasSize.y)
            engine = FloatingIconEngine(rect, homeApps.map { it.packageName }, iconRadiusPx)
        }
    }

    LaunchedEffect(engine) {
        while (engine != null) {
            engine?.step(1f / 60f)
            delay(16)
        }
    }

    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var renameApp by remember { mutableStateOf<AppInfo?>(null) }

    val iconPicker = rememberLauncherForActivityResultCompat { uri ->
        val target = menuApp
        if (uri != null && target != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) { /* some providers don't support persistable perms - ignore */ }
            onIconAction(HomeIconAction.ChangeIcon(target.packageName, uri.toString()))
        }
        menuApp = null
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TermBg)
            .then(Modifier.onGloballyPositioned { coords ->
                canvasSize = Offset(coords.size.width.toFloat(), coords.size.height.toFloat())
            })
    ) {
        ScanlineOverlay()

        // Terminal-style status bar with a live clock and blinking cursor
        TerminalPrompt(modifier = Modifier.align(Alignment.TopCenter))

        val currentEngine = engine
        if (currentEngine != null) {
            currentEngine.bodies.forEach { body ->
                val app = homeApps.find { it.packageName == body.id } ?: return@forEach
                val xDp = with(density) { body.x.value.toDp() }
                val yDp = with(density) { body.y.value.toDp() }
                val sizeDp = with(density) { (body.radius * 2).toDp() }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .offset(x = xDp - sizeDp / 2, y = yDp - sizeDp / 2)
                        .width(sizeDp + 20.dp)
                        .pointerInput(app.packageName) {
                            detectTapGestures(
                                onTap = { onLaunch(app.packageName) },
                                onLongPress = { menuApp = app }
                            )
                        }
                ) {
                    BracketFrame(sizeDp) {
                        bitmaps[app.packageName]?.let { bmp ->
                            Canvas(modifier = Modifier.size(sizeDp - 10.dp)) {
                                drawImage(bmp)
                            }
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = "[${app.label}]",
                        color = TermGreen,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        } else if (homeApps.isEmpty()) {
            Text(
                "> no apps pinned to home_\n> open app drawer to add one",
                color = TermGreen,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(40.dp)
        ) {
            FilledIconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
            FilledIconButton(onClick = onOpenDrawer) {
                Icon(Icons.Filled.Apps, contentDescription = "App drawer")
            }
        }
    }

    menuApp?.let { app ->
        AlertDialog(
            onDismissRequest = { menuApp = null },
            title = { Text(app.label, fontFamily = FontFamily.Monospace) },
            text = {
                Column {
                    TextButton(onClick = {
                        renameApp = app
                        menuApp = null
                    }) { Text("> rename") }
                    TextButton(onClick = { iconPicker() }) { Text("> change icon") }
                    TextButton(onClick = {
                        onIconAction(HomeIconAction.RemoveFromHome(app.packageName))
                        menuApp = null
                    }) { Text("> remove from home") }
                }
            },
            confirmButton = {
                TextButton(onClick = { menuApp = null }) { Text("close") }
            }
        )
    }

    renameApp?.let { app ->
        var text by remember(app.packageName) { mutableStateOf(app.label) }
        AlertDialog(
            onDismissRequest = { renameApp = null },
            title = { Text("rename ${app.label}", fontFamily = FontFamily.Monospace) },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    onIconAction(HomeIconAction.Rename(app.packageName, text))
                    renameApp = null
                }) { Text("save") }
            },
            dismissButton = {
                TextButton(onClick = { renameApp = null }) { Text("cancel") }
            }
        )
    }
}

/** Corner-bracket "targeting reticle" frame around each icon - the app's signature visual element. */
@Composable
private fun BracketFrame(size: androidx.compose.ui.unit.Dp, content: @Composable BoxScope.() -> Unit) {
    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val tick = this.size.minDimension * 0.22f
            val strokeWidth = 2.5f
            val w = this.size.width
            val h = this.size.height
            drawLine(TermGreen, Offset(0f, tick), Offset(0f, 0f), strokeWidth, StrokeCap.Round)
            drawLine(TermGreen, Offset(0f, 0f), Offset(tick, 0f), strokeWidth, StrokeCap.Round)

            drawLine(TermGreen, Offset(w - tick, 0f), Offset(w, 0f), strokeWidth, StrokeCap.Round)
            drawLine(TermGreen, Offset(w, 0f), Offset(w, tick), strokeWidth, StrokeCap.Round)

            drawLine(TermGreen, Offset(0f, h - tick), Offset(0f, h), strokeWidth, StrokeCap.Round)
            drawLine(TermGreen, Offset(0f, h), Offset(tick, h), strokeWidth, StrokeCap.Round)

            drawLine(TermGreen, Offset(w - tick, h), Offset(w, h), strokeWidth, StrokeCap.Round)
            drawLine(TermGreen, Offset(w, h - tick), Offset(w, h), strokeWidth, StrokeCap.Round)
        }
        content()
    }
}

/** Faint horizontal scanlines for a CRT-terminal feel - subtle, not a cliché flat glow. */
@Composable
private fun ScanlineOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val lineGap = 4.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = Color.White.copy(alpha = 0.02f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f
            )
            y += lineGap
        }
    }
}

@Composable
private fun TerminalPrompt(modifier: Modifier = Modifier) {
    var timeText by remember { mutableStateOf(currentTimeString()) }
    LaunchedEffect(Unit) {
        while (true) {
            timeText = currentTimeString()
            delay(1000)
        }
    }
    val transition = rememberInfiniteTransition(label = "cursor-blink")
    val cursorAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursor-alpha"
    )

    Row(
        modifier = modifier
            .padding(top = 40.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "root@bidhan:~$ $timeText",
            color = TermGreen,
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            text = " _",
            color = TermGreen.copy(alpha = cursorAlpha),
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private fun currentTimeString(): String =
    SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

/** Small wrapper so callers can trigger the gallery picker like a function call. */
@Composable
private fun rememberLauncherForActivityResultCompat(onResult: (Uri?) -> Unit): () -> Unit {
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri -> onResult(uri) }
    return { launcher.launch("image/*") }
}

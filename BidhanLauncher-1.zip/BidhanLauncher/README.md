# Bidhan Launcher

তোমার নিজের, একদম নিজের কন্ট্রোলে থাকা Android launcher app। Play Store বা কোনো
থার্ড-পার্টি APK modify করা হয়নি — পুরোটাই স্ক্র্যাচ থেকে Kotlin + Jetpack
Compose দিয়ে বানানো।

## Phase 1 (এই ভার্সনে যা আছে)
- Home screen-এ icon গুলো ধীরে ধীরে ভেসে বেড়ায় (gravity/floating physics),
  একে অপরের সাথে ধাক্কা লাগলে বাউন্স করে অন্যদিকে সরে যায়
- App drawer — search সহ, সব installed app দেখা যায়
- কোন app home screen-এ থাকবে, কোনটা hide (লুকানো) থাকবে — নিজে সেট করা যায়
- App-এর display নাম change করা যায় (rename)
- নিচ থেকে swipe করলে কিছু হয় না — accidental trigger বন্ধ, শুধু বাটনে চাপ
  দিলেই drawer/settings খোলে
- Kali/Termux-স্টাইল dark, green-on-black theme
- হালকা — কোনো ad, tracker, বা background network call নাই
- AI মডিউল কোডে **রাখা আছে কিন্তু বন্ধ** (`AiAssistantStub.ENABLED = false`) —
  পরের update-এ চালু করা যাবে, নিজের API key দিয়ে (কোনো hidden key বান্ডিল
  করা হয়নি)

## Phase 2 (পরের update-এ)
- Custom icon pack support
- Home screen widgets
- Home icon-এর নিজস্ব icon change (gallery থেকে ছবি বাছাই)

## Phase 3 (পরের update-এ, optional)
- Assistant চালু করা — এটা কাজ করবে তখনই যখন তুমি নিজের Anthropic/Claude API
  key সেটিংসে বসাবে। কোনো free/hidden AI backend থাকবে না — Play Store নীতি
  ও ইউজার প্রাইভেসি রক্ষার জন্যই এই ডিজাইন।

## Build করবে কীভাবে (GitHub Actions দিয়ে, phone থেকেই)
1. এই পুরো ফোল্ডারটা GitHub repo-তে push করো (`main` branch)
2. `Actions` ট্যাবে যাও → workflow নিজে থেকেই চলবে (push হলে) অথবা
   "Run workflow" চাপো
3. build শেষ হলে Artifacts থেকে `bidhan-launcher-debug` ডাউনলোড করো — এটাই
   তোমার APK (zip-এর ভিতরে)

## ইনস্টল করার পর
ফোনের **Settings → Apps → Default apps → Home app** থেকে "Bidhan" সিলেক্ট
করলেই এটা তোমার default launcher হয়ে যাবে।

## Local-এ Android Studio দিয়ে build
এই ফোল্ডার Android Studio-তে খুলে সরাসরি Run করলেই চলবে (compileSdk/targetSdk
36, min SDK 26)।

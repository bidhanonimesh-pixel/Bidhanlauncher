package com.bidhan.launcher.ai

/**
 * Placeholder only. AI is intentionally OFF for now - this app makes no
 * network calls anywhere. When enabled in a future update, this is where
 * an opt-in, user-supplied-API-key based assistant would be wired in
 * (never bundled with a hidden key, never on by default).
 */
object AiAssistantStub {
    const val ENABLED = false

    fun notReadyMessage(): String =
        "AI assistant পরের একটা update-এ আসবে। নিজের API key দিলে তবেই চালু হবে।"
}

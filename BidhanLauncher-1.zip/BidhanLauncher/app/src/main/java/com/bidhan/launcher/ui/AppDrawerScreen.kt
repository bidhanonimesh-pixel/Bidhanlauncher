package com.bidhan.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.bidhan.launcher.data.AppInfo
import com.bidhan.launcher.ui.theme.TermBg
import com.bidhan.launcher.ui.theme.TermGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDrawerScreen(
    allApps: List<AppInfo>,
    homeAppPackages: Set<String>,
    onBack: () -> Unit,
    onLaunch: (String) -> Unit,
    onToggleHome: (String) -> Unit,
    onToggleHidden: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, allApps) {
        if (query.isBlank()) allApps
        else allApps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize().background(TermBg)) {
        TopAppBar(
            title = { Text("সব App", color = TermGreen) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TermGreen)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = TermBg)
        )

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search apps...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TermGreen,
                unfocusedTextColor = TermGreen,
                focusedBorderColor = TermGreen,
                cursorColor = TermGreen
            )
        )

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered, key = { it.packageName }) { app ->
                AppRow(
                    app = app,
                    isOnHome = app.packageName in homeAppPackages,
                    onClick = { onLaunch(app.packageName) },
                    onToggleHome = { onToggleHome(app.packageName) },
                    onToggleHidden = { onToggleHidden(app.packageName) }
                )
            }
        }
    }
}

@Composable
private fun AppRow(
    app: AppInfo,
    isOnHome: Boolean,
    onClick: () -> Unit,
    onToggleHome: () -> Unit,
    onToggleHidden: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.foundation.Image(
            bitmap = remember(app.packageName) {
                val bmp = android.graphics.Bitmap.createBitmap(96, 96, android.graphics.Bitmap.Config.ARGB_8888)
                val c = android.graphics.Canvas(bmp)
                app.icon.setBounds(0, 0, 96, 96)
                app.icon.draw(c)
                bmp.asImageBitmap()
            },
            contentDescription = app.label,
            modifier = Modifier.size(40.dp).clickableCompat(onClick)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = app.label,
            color = TermGreen,
            modifier = Modifier.weight(1f).clickableCompat(onClick)
        )
        IconButton(onClick = onToggleHome) {
            Icon(
                Icons.Filled.Home,
                contentDescription = "Add/remove home",
                tint = if (isOnHome) TermGreen else TermGreen.copy(alpha = 0.35f)
            )
        }
        IconButton(onClick = onToggleHidden) {
            Icon(Icons.Filled.VisibilityOff, contentDescription = "Hide app", tint = TermGreen.copy(alpha = 0.6f))
        }
    }
}

private fun Modifier.clickableCompat(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))

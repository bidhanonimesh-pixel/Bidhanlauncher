package com.bidhan.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

val TermGreen = Color(0xFF00FF66)
val TermGreenDim = Color(0xFF00B84D)
val TermBg = Color(0xFF0A0A0A)
val TermSurface = Color(0xFF111512)
val TermRed = Color(0xFFFF4444)

private val BidhanColorScheme = darkColorScheme(
    primary = TermGreen,
    onPrimary = Color.Black,
    secondary = TermGreenDim,
    background = TermBg,
    onBackground = TermGreen,
    surface = TermSurface,
    onSurface = TermGreen,
    error = TermRed
)

@Composable
fun BidhanLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BidhanColorScheme,
        typography = MaterialTheme.typography.copy(
            bodyLarge = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
            bodyMedium = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
            labelLarge = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace)
        ),
        content = content
    )
}

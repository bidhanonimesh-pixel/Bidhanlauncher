package com.bidhan.launcher.physics

import androidx.compose.runtime.mutableStateOf
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * One home-screen icon. Spends most of its time completely still and
 * occasionally drifts a short distance in a random direction, the way the
 * user described: "normally still, sometimes floats up/down/left/right,
 * bumps into another icon, separates, drifts off a different way."
 */
class FloatingBody(
    val id: String,
    startX: Float,
    startY: Float,
    val radius: Float
) {
    var x = mutableStateOf(startX)
    var y = mutableStateOf(startY)
    var vx = 0f
    var vy = 0f
    var isDrifting = false
    // starts staggered so icons don't all move in sync
    var stateTimer = Random.nextFloat() * 6f + 2f
}

/**
 * Lightweight custom physics loop - no external physics library needed.
 * Icons idle by default, occasionally pick a random drift direction for a
 * short burst, bounce off screen edges, and elastically bounce off each
 * other so two icons never overlap.
 */
class FloatingIconEngine(
    private val bounds: androidx.compose.ui.geometry.Rect,
    ids: List<String>,
    iconRadiusPx: Float
) {
    val bodies: List<FloatingBody> = ids.mapIndexed { index, id ->
        val cols = 4
        val col = index % cols
        val row = index / cols
        FloatingBody(
            id = id,
            startX = bounds.left + iconRadiusPx * 2.4f + col * (bounds.width / cols),
            startY = bounds.top + iconRadiusPx * 2.4f + row * (iconRadiusPx * 3.6f),
            radius = iconRadiusPx
        )
    }

    private val driftSpeedRange = 14f..34f
    private val driftDurationRange = 0.8f..2.2f
    private val idleDurationRange = 3.5f..9f

    /** Advance the simulation by [dtSeconds]. Call this ~60 times/sec. */
    fun step(dtSeconds: Float) {
        for (b in bodies) {
            b.stateTimer -= dtSeconds
            if (b.stateTimer <= 0f) {
                if (b.isDrifting) {
                    // settle back down
                    b.vx = 0f
                    b.vy = 0f
                    b.isDrifting = false
                    b.stateTimer = idleDurationRange.random()
                } else {
                    val angle = Random.nextFloat() * (2 * Math.PI).toFloat()
                    val speed = driftSpeedRange.random()
                    b.vx = cos(angle) * speed
                    b.vy = sin(angle) * speed
                    b.isDrifting = true
                    b.stateTimer = driftDurationRange.random()
                }
            }

            if (b.vx == 0f && b.vy == 0f) continue

            var nx = b.x.value + b.vx * dtSeconds
            var ny = b.y.value + b.vy * dtSeconds

            if (nx - b.radius < bounds.left) {
                nx = bounds.left + b.radius
                b.vx = -b.vx
            } else if (nx + b.radius > bounds.right) {
                nx = bounds.right - b.radius
                b.vx = -b.vx
            }
            if (ny - b.radius < bounds.top) {
                ny = bounds.top + b.radius
                b.vy = -b.vy
            } else if (ny + b.radius > bounds.bottom) {
                ny = bounds.bottom - b.radius
                b.vy = -b.vy
            }

            b.x.value = nx
            b.y.value = ny
        }

        // pairwise collision - a still icon gets nudged into drifting too
        for (i in bodies.indices) {
            for (j in i + 1 until bodies.size) {
                val a = bodies[i]
                val c = bodies[j]
                val dx = c.x.value - a.x.value
                val dy = c.y.value - a.y.value
                val dist = sqrt(dx * dx + dy * dy)
                val minDist = a.radius + c.radius
                if (dist in 0.01f..minDist) {
                    val nx = dx / dist
                    val ny = dy / dist
                    val overlap = (minDist - dist) / 2f
                    a.x.value -= nx * overlap
                    a.y.value -= ny * overlap
                    c.x.value += nx * overlap
                    c.y.value += ny * overlap

                    // wake both icons up and send them apart
                    val speed = driftSpeedRange.random()
                    a.vx = -nx * speed
                    a.vy = -ny * speed
                    c.vx = nx * speed
                    c.vy = ny * speed
                    a.isDrifting = true
                    c.isDrifting = true
                    a.stateTimer = driftDurationRange.random()
                    c.stateTimer = driftDurationRange.random()
                }
            }
        }
    }

    private fun ClosedFloatingPointRange<Float>.random(): Float =
        start + Random.nextFloat() * (endInclusive - start)
}

package com.bidhan.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bidhan.launcher.data.AppInfo
import com.bidhan.launcher.ui.theme.TermBg
import com.bidhan.launcher.ui.theme.TermGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    allApps: List<AppInfo>,
    hiddenApps: Set<String>,
    onBack: () -> Unit,
    onUnhide: (String) -> Unit,
    onRename: (String, String) -> Unit
) {
    var renameTarget by remember { mutableStateOf<AppInfo?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(TermBg)) {
        TopAppBar(
            title = { Text("Settings", color = TermGreen) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TermGreen)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = TermBg)
        )

        Text(
            "লুকানো (Hidden) Apps",
            color = TermGreen,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(16.dp)
        )

        val hiddenList = allApps.filter { it.packageName in hiddenApps }
        if (hiddenList.isEmpty()) {
            Text(
                "কোনো app hide করা নেই।",
                color = TermGreen.copy(alpha = 0.6f),
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        } else {
            LazyColumn(modifier = Modifier.weight(1f, fill = false).heightIn(max = 260.dp)) {
                items(hiddenList, key = { it.packageName }) { app ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(app.label, color = TermGreen, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onUnhide(app.packageName) }) {
                            Text("Unhide", color = TermGreen)
                        }
                    }
                }
            }
        }

        Divider(color = TermGreen.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 12.dp))

        Text(
            "App নাম পরিবর্তন করো",
            color = TermGreen,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(allApps, key = { it.packageName }) { app ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(app.label, color = TermGreen, modifier = Modifier.weight(1f))
                    TextButton(onClick = { renameTarget = app }) {
                        Text("Rename", color = TermGreen)
                    }
                }
            }
        }

        Divider(color = TermGreen.copy(alpha = 0.2f))

        // Reserved space for a future update - not active yet.
        Column(modifier = Modifier.padding(16.dp)) {
            Text("AI Assistant", color = TermGreen.copy(alpha = 0.5f), style = MaterialTheme.typography.titleMedium)
            Text(
                "শীঘ্রই আসছে - এখন বন্ধ আছে, কোনো নেটওয়ার্ক কল হয় না।",
                color = TermGreen.copy(alpha = 0.4f),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    renameTarget?.let { app ->
        var text by remember(app.packageName) { mutableStateOf(app.label) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            confirmButton = {
                TextButton(onClick = {
                    onRename(app.packageName, text)
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            },
            title = { Text("Rename ${app.label}") },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
            }
        )
    }
}

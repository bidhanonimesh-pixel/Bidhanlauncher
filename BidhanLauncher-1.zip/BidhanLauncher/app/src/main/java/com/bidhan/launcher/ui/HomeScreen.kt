package com.bidhan.launcher.ui

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bidhan.launcher.data.AppInfo
import com.bidhan.launcher.physics.FloatingIconEngine
import com.bidhan.launcher.ui.theme.TermBg
import com.bidhan.launcher.ui.theme.TermGreen
import kotlinx.coroutines.delay

private fun Drawable.toBitmap(size: Int): android.graphics.Bitmap {
    val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bmp
}

@Composable
fun HomeScreen(
    homeApps: List<AppInfo>,
    onLaunch: (String) -> Unit,
    onLongPressApp: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val density = LocalDensity.current
    var canvasSize by remember { mutableStateOf(Offset.Zero) }
    val iconRadiusPx = with(density) { 28.dp.toPx() }

    val bitmaps = remember(homeApps) {
        homeApps.associate { it.packageName to it.icon.toBitmap(140).asImageBitmap() }
    }

    var engine by remember(homeApps, canvasSize) { mutableStateOf<FloatingIconEngine?>(null) }

    LaunchedEffect(homeApps, canvasSize) {
        if (canvasSize.x > 0 && canvasSize.y > 0 && homeApps.isNotEmpty()) {
            val rect = Rect(0f, 0f, canvasSize.x, canvasSize.y)
            engine = FloatingIconEngine(rect, homeApps.map { it.packageName }, iconRadiusPx)
        }
    }

    // physics tick - ~60fps
    LaunchedEffect(engine) {
        while (engine != null) {
            engine?.step(1f / 60f)
            delay(16)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TermBg)
            .then(Modifier.onGloballyPositioned { coords ->
                canvasSize = Offset(coords.size.width.toFloat(), coords.size.height.toFloat())
            })
    ) {
        val currentEngine = engine
        if (currentEngine != null) {
            // Invisible tap targets follow the animated positions
            currentEngine.bodies.forEach { body ->
                val app = homeApps.find { it.packageName == body.id } ?: return@forEach
                val xDp = with(density) { body.x.value.toDp() }
                val yDp = with(density) { body.y.value.toDp() }
                val sizeDp = with(density) { (body.radius * 2).toDp() }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .offset(x = xDp - sizeDp / 2, y = yDp - sizeDp / 2)
                        .width(sizeDp + 16.dp)
                        .pointerInput(app.packageName) {
                            detectTapGestures(
                                onTap = { onLaunch(app.packageName) },
                                onLongPress = { onLongPressApp(app) }
                            )
                        }
                ) {
                    bitmaps[app.packageName]?.let { bmp ->
                        Canvas(modifier = Modifier.size(sizeDp)) {
                            drawImage(bmp)
                        }
                    }
                    Text(
                        text = app.label,
                        color = TermGreen,
                        style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        } else if (homeApps.isEmpty()) {
            Text(
                "কোনো app home-এ যোগ করা হয়নি।\nApp drawer থেকে যোগ করো।",
                color = TermGreen,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }

        // Manual controls only - no swipe-up gesture so nothing opens by accident
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(40.dp)
        ) {
            FilledIconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
            FilledIconButton(onClick = onOpenDrawer) {
                Icon(Icons.Filled.Apps, contentDescription = "App drawer")
            }
        }
    }
}



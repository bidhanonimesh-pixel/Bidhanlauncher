package com.bidhan.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "bidhan_launcher_prefs")

/**
 * All settings are stored locally on-device only (DataStore). Nothing is
 * uploaded anywhere.
 */
object PrefsManager {

    private val HIDDEN_APPS = stringSetPreferencesKey("hidden_apps")
    private val HOME_APPS = stringSetPreferencesKey("home_apps")
    private val CUSTOM_NAMES = stringSetPreferencesKey("custom_names") // "pkg||name"
    private val CUSTOM_ICONS = stringSetPreferencesKey("custom_icons") // "pkg||uri"

    // Reserved for a future update. AI is OFF by default and does nothing
    // right now - no network calls are made anywhere in this app.
    private val AI_ENABLED = booleanPreferencesKey("ai_enabled")
    private val AI_API_KEY = stringPreferencesKey("ai_api_key")

    fun hiddenApps(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[HIDDEN_APPS] ?: emptySet() }

    fun homeApps(context: Context): Flow<Set<String>> =
        context.dataStore.data.map { it[HOME_APPS] ?: emptySet() }

    fun customNames(context: Context): Flow<Map<String, String>> =
        context.dataStore.data.map { prefs ->
            (prefs[CUSTOM_NAMES] ?: emptySet()).associate {
                val (pkg, name) = it.split("||", limit = 2)
                pkg to name
            }
        }

    fun customIcons(context: Context): Flow<Map<String, String>> =
        context.dataStore.data.map { prefs ->
            (prefs[CUSTOM_ICONS] ?: emptySet()).associate {
                val (pkg, uri) = it.split("||", limit = 2)
                pkg to uri
            }
        }

    suspend fun toggleHidden(context: Context, pkg: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[HIDDEN_APPS] ?: emptySet()
            prefs[HIDDEN_APPS] = if (pkg in current) current - pkg else current + pkg
        }
    }

    suspend fun toggleHome(context: Context, pkg: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[HOME_APPS] ?: emptySet()
            prefs[HOME_APPS] = if (pkg in current) current - pkg else current + pkg
        }
    }

    suspend fun setCustomName(context: Context, pkg: String, name: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[CUSTOM_NAMES] ?: emptySet()).filterNot { it.startsWith("$pkg||") }.toSet()
            prefs[CUSTOM_NAMES] = current + "$pkg||$name"
        }
    }

    suspend fun setCustomIcon(context: Context, pkg: String, uri: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[CUSTOM_ICONS] ?: emptySet()).filterNot { it.startsWith("$pkg||") }.toSet()
            prefs[CUSTOM_ICONS] = current + "$pkg||$uri"
        }
    }

    // --- Reserved for future AI update. Not wired to any UI yet. ---
    fun aiEnabled(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[AI_ENABLED] ?: false }

    suspend fun setAiEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { it[AI_ENABLED] = enabled }
    }

    suspend fun setAiApiKey(context: Context, key: String) {
        context.dataStore.edit { it[AI_API_KEY] = key }
    }
}

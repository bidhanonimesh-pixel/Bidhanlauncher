package com.bidhan.launcher.physics

import androidx.compose.runtime.mutableStateOf
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * One floating app icon. Position/velocity in px, updated every frame.
 */
class FloatingBody(
    val id: String,
    startX: Float,
    startY: Float,
    val radius: Float
) {
    var x = mutableStateOf(startX)
    var y = mutableStateOf(startY)
    var vx = Random.nextFloat() * 60f - 30f   // px/sec, gentle drift
    var vy = Random.nextFloat() * 60f - 30f
}

/**
 * Very light custom physics loop: constant gentle drift, elastic bounce off
 * screen edges, and simple elastic collision between icons so they never
 * overlap - they "meet, bump, and drift off in a new direction".
 */
class FloatingIconEngine(
    private val bounds: androidx.compose.ui.geometry.Rect,
    ids: List<String>,
    iconRadiusPx: Float
) {
    val bodies: List<FloatingBody> = ids.mapIndexed { index, id ->
        val cols = 4
        val col = index % cols
        val row = index / cols
        FloatingBody(
            id = id,
            startX = bounds.left + iconRadiusPx * 2 + col * (bounds.width / cols),
            startY = bounds.top + iconRadiusPx * 2 + row * (iconRadiusPx * 3.2f),
            radius = iconRadiusPx
        )
    }

    /** Advance the simulation by [dtSeconds]. Call this ~60 times/sec. */
    fun step(dtSeconds: Float) {
        // integrate positions
        for (b in bodies) {
            var nx = b.x.value + b.vx * dtSeconds
            var ny = b.y.value + b.vy * dtSeconds

            if (nx - b.radius < bounds.left) {
                nx = bounds.left + b.radius
                b.vx = -b.vx
            } else if (nx + b.radius > bounds.right) {
                nx = bounds.right - b.radius
                b.vx = -b.vx
            }
            if (ny - b.radius < bounds.top) {
                ny = bounds.top + b.radius
                b.vy = -b.vy
            } else if (ny + b.radius > bounds.bottom) {
                ny = bounds.bottom - b.radius
                b.vy = -b.vy
            }

            b.x.value = nx
            b.y.value = ny
        }

        // pairwise collision - icons bump off each other and change direction
        for (i in bodies.indices) {
            for (j in i + 1 until bodies.size) {
                val a = bodies[i]
                val c = bodies[j]
                val dx = c.x.value - a.x.value
                val dy = c.y.value - a.y.value
                val dist = sqrt(dx * dx + dy * dy)
                val minDist = a.radius + c.radius
                if (dist in 0.01f..minDist) {
                    // normal vector
                    val nx = dx / dist
                    val ny = dy / dist
                    // separate so they don't stick
                    val overlap = (minDist - dist) / 2f
                    a.x.value -= nx * overlap
                    a.y.value -= ny * overlap
                    c.x.value += nx * overlap
                    c.y.value += ny * overlap
                    // swap velocity along normal (elastic, equal mass)
                    val avn = a.vx * nx + a.vy * ny
                    val cvn = c.vx * nx + c.vy * ny
                    a.vx += (cvn - avn) * nx
                    a.vy += (cvn - avn) * ny
                    c.vx += (avn - cvn) * nx
                    c.vy += (avn - cvn) * ny
                }
            }
        }
    }
}
